class Persistencia {
    constructor () {
        this.datos = [{palabra: "prueba"},
        {palabra: "dsa"},
        {palabra: "asd"}
            ]
    }

    obtenerDatos = () => {
        return this.datos
    }


    obtenerFrase = (palabra, cantPalabras) => { 
        palabra = palabra-1

        if (palabra < 0 || palabra + cantPalabras > this.datos.length) {
            throw new Error("Índice fuera de rango"); 
          }

        
        const palabrasFrase = this.datos.slice(palabra, palabra + cantPalabras);

        return palabrasFrase
    }

    agregarPalabras = palabras => {
        const arrayDePalabras= palabras.split(' ')
        
        for (var i = 0; i < arrayDePalabras.length; i++) {

            this.datos.push({"palabra": arrayDePalabras[i]});
          }

        return this.datos
    }

    


}

export default Persistencia