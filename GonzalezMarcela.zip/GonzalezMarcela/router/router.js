import express from "express";
import Controladoooooo from "../controlador/controlador.js";

class RouterServicios {
    constructor() {
        this.router = express.Router()
        this.controlador = new Controladoooooo()
    }

    start () {
        
        this.router.post('/palabras', this.controlador.agregarPalabras)
        this.router.get('/mostrar', this.controlador.getFrase)
        this.router.get('/obtenerFrasePorIndice/:indice/:cantPalabras', this.controlador.obtenerFrasePorIndice)
        

        return this.router
    }
}


export default RouterServicios