import Servicio from "../servicio/servicio.js"


class Controladoooooo {
    constructor() {
        this.servicio = new Servicio()
    }

    
    agregarPalabras = (req, res) => {
        const { palabras } = req.body
        const resultado = this.servicio.agregarPalabras(palabras)
        res.json(resultado)
    }

    getFrase = (req, res) => {
        const frase = this.servicio.obtenerString()
        res.json({frase})
    }

    obtenerFrasePorIndice = (req, res) => {
        try{
            const { indice, cantPalabras } = req.params
            const frase = this.servicio.obtenerFrasePorIndice(indice,cantPalabras)
            res.json({frase})
        }catch(error){
            res.json(error.message) 
        }
        
    }

}

export default Controladoooooo