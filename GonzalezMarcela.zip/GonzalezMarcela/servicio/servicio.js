import Persistencia from "../persistencia/capaPersistencia.js";

class Servicio {
    constructor() {
        this.persistencia = new Persistencia()
    }

    obtenerString() {
        const frase = this.persistencia.obtenerDatos()
        const arrayPalabras= frase.map((obj) => obj.palabra);
        return arrayPalabras
    }

    obtenerFrasePorIndice(indice,cantPalabras) {
        const frase = this.persistencia.obtenerFrase(indice, cantPalabras)
        const arrayPalabras= frase.map((obj) => obj.palabra);
        return arrayPalabras
    }

    agregarPalabras(palabras) {
        var res = this.persistencia.agregarPalabras(palabras)
        return res
    }
}

export default Servicio